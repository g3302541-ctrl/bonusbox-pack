================================================================================
                    BONUSBOX CUSTOM UI RESOURCE PACK
================================================================================

Minecraft Java Edition compatibility:
- This archive is for the version range shown in pack.mcmeta.
- The original textures and bitmap-font artwork are unchanged.
- The private-use glyphs are registered in assets/minecraft/font/default.json.

Included live UI elements:
- TAB header artwork: glyph U+E001
- Scoreboard header/footer artwork: glyphs U+E005 and U+E006
- Statistics icons: glyphs U+E010 through U+E015
- Existing rank badges: ADMIN, MOD, HELPER, VIP and PLAYER

Important:
- Use the archive matching the Minecraft Java version.
- TAB must send the Unicode glyphs directly; ItemsAdder-style %font:...% placeholders are not required.
- Kills, deaths and balance require PlaceholderAPI with the Statistic and Vault expansions.
- "Фантики: 0" and "BattlePass Уровень: 5" are sample values until replaced with placeholders from the server's own plugins.
- The decorative TAB footer U+E002 and full static frame glyphs U+E003/U+E004 are not used by the supplied live config because their images contain fixed/demo content.

Installation:
1. Put the ZIP in .minecraft/resourcepacks and activate it.
2. For server delivery, host the ZIP and set resource-pack in server.properties.
3. Install the companion TAB configuration and run the LuckPerms rank setup commands.

================================================================================


FIX NOTE (for the 1.21.4-1.21.8 build): Oversized font bitmap artworks are supplied as downscaled glyph-only copies so each glyph fits Minecraft's 256x256 bitmap-atlas limit. The original PNG artwork files are kept unchanged.
